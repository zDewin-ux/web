import { CrearUsuarioComponent } from './crear-usuario/crear-usuario.component';

const routes: Routes = [
  { path: 'crear-usuario', component: CrearUsuarioComponent },
];
